window.onscroll = function () { myFunction() };

function myFunction() {
	var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
	var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
	var scrolled = (winScroll / height) * 100;
	document.getElementById("myScroll").style.width = scrolled + "%";
}

function play() {
	var audio = document.getElementById("audio");
	audio.play();
}

function mouseOver() {
	document.getElementById("demo").style.color = "#f79e9e";
}
function isEmail() {
	var str = document.getElementById("email").value;
	var status = document.getElementById("status");
	var re = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i;
	if (re.test(str)) status.innerHTML = "We send you message";
	else status.innerHTML = "Adress is wrong";
	if (isEmpty(str)) status.innerHTML = "Not filled";
}
function isEmpty(str) {
	return (str == null) || (str.length == 0);
}